1.paste- question images to "qtn_imgs" name called folder as per the doc image.

2. src='../qtn_imgs/paste-image name with file extension'

3.Looks like
<img src='../qtn_imgs/q1.jpg' width='100%'/>
									 ---^^^^^^---
										 {q1.jpg}-image name with extension

4.And last paste- <img> tag in "question input felid or options felid." Where you want.(question Object Generator).

*img tag Structure same exact
<img src='../qtn_imgs/q1.jpg' width='100%'/>